package com.company;

import Task1.DemoMultiThread;
import Task2.Demo;

public class Main {

    public static void main(String[] args) {
        DemoMultiThread.main();
        Demo.main();
        Task3.Demo.main();
    }
}
