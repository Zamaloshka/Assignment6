package Task3.builders;

import Task3.cars.CarType;
import Task3.components.Engine;
import Task3.components.GPSNavigator;
import Task3.components.Transmission;
import Task3.components.TripComputer;

/**
 * Builder interface defines all possible ways to configure a product.
 */
public interface Builder {
    void setCarType(CarType type);
    void setSeats(int seats);
    void setEngine(Engine engine);
    void setTransmission(Transmission transmission);
    void setTripComputer(TripComputer tripComputer);
    void setGPSNavigator(GPSNavigator gpsNavigator);
}
